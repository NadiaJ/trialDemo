import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;


public class MovieTest extends TestCase {

	public void testMovieCharge(){
		Movie movie=new Movie("Despicable Me 2",200);
		movie.charge(7);
		Movie movie1 = movie;
		assertEquals(1400,movie.charges);
		movie.charge(10);
		movie1=movie;
		assertEquals(2000,movie1.charges);
	}
}

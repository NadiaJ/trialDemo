
public class Movie {
	 String movie_name;
	  int price;
	  int charges;
	  
	public Movie(String movie_name, int price) {
		
	}


	public void charge(int days)
	{
		
	}


}

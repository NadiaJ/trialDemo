
 
public class Movie {
	 
	String movie_name;
	Price curr_price=null;  
	
	
	public Movie(String movie_name) {
		this.movie_name=movie_name;
		
	}

	public String getMovie_name() {
		return movie_name;
	}


	public static Movie newNewRelease(String name){ 
		 Movie result = new Movie (name); 
		 result.beNewRelease(); 
		 return result; 
		 } 
	
	public static Movie newRegular(String name){ 
		 Movie result = new Movie (name); 
		 result.beRegular(); 
		 return result; 
		 } 
		 
		 public static Movie newChildrens(String name) { 
		 Movie result = new Movie (name); 
		 result.beChildrens(); 
		 return result; 
		 } 
		 
		 public void beRegular() { 
			 curr_price = Price.regular(); 
			 }
		 
		public void beNewRelease() { 
			curr_price = Price.newRelease(); 
			 } 
			 
		public void beChildrens() { 
			curr_price = Price.childrens(); 
			 }
		 	 	 
		public Price getCurrentPrice()
		{
			return curr_price;
		}
		public int getCharge(){
			return curr_price.getCharge();
		}

}

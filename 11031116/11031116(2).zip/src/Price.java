 abstract class Price{
	
	static Price children=new Children();
	static Price newreleases=new NewReleases();
	static Price regular=new Regular();
	

	public static Price regular()
	{
		return regular;
	}
	
	public static Price childrens()
	{
		return children;
	}
	
	public static Price newRelease()
	{
		return newreleases;
	}
	
		
	abstract int getCharge(); 
			
		 
		 
	
}
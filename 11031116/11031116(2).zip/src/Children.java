
public class Children extends Price{

	@Override
	int getCharge() {
		
		return 180;
	}


	

}

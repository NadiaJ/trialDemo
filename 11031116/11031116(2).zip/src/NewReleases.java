
public class NewReleases extends Price{

	@Override
	int getCharge() {
		
		return 200;
	}

	
	

}

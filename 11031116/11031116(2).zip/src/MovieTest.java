import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class MovieTest {

	Movie movie;
	@Before
	public void setUp() throws Exception {
		 movie = new Movie("Avatar");
	}

	@Test
	public void testMovieName() {
		assertEquals("Avatar", movie.getMovie_name());
	}

	
	
}



public class Rental {
	
	Movie movie;
	int noOfDays;
	
	public Rental(int days,Movie m) {
		this.noOfDays=days;
		this.movie=m;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	
	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	
	
	public void getRentalCharges(){
		double rent;
		double rate;
		if(movie.getCurrentPrice().getClass()==NewReleases.class)
		{
			rate=0.9;
		}
		
		else if(movie.getCurrentPrice().getClass()==Regular.class)
		{
			rate=0.5;
		}
		else{
			 rate=0.3;
		}
		 rent=(((rate*movie.getCharge())+movie.getCharge())*(noOfDays));
		 	System.out.println(rent);
	}
	
	
}

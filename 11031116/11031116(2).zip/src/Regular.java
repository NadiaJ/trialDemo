
public class Regular extends Price{

	@Override
	int getCharge() {
		
		return 120;
	}

	

}

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class RentalTest {
	Movie movie1;
    Rental rent;


	public void setUp() throws Exception {
		movie1=new Movie("Despicable me");
		movie1.beNewRelease();
		rent=new Rental(5,movie1);
	}

	@Test
	public void testRentalDays() {
		assertEquals(5,rent.getNoOfDays());
	}

	
}

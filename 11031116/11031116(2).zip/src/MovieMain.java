
public class MovieMain {
	
	
	
	public static void main(String[] args) {
		
		Movie m=new Movie("Iron Man" );
		m.beNewRelease();
		Rental r=new Rental(5,m);
		
		r.getRentalCharges();
		System.out.print(r.getNoOfDays());

	}

}
